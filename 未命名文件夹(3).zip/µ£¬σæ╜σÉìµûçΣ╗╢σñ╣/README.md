## 笔记
https://www.yuque.com/books/share/84a225ba-970e-46ee-9e72-b09a297d75fe?#（密码：slzd）

https://cn.vitejs.dev/

https://eslint.org/docs/user-guide/getting-started

https://github.com/okonet/lint-staged
npx mrm@2 lint-staged

https://github.com/vuejs/rfcs/blob/master/active-rfcs/0040-script-setup.md

https://github.com/vuejs/jsx-next

https://next.router.vuejs.org/zh/installation.html

https://github.com/vuejs/vuex/tree/4.0

https://next.vuex.vuejs.org/zh/index.html

https://github.com/axios/axios

# elementPlus
https://github.com/element-plus/element-plus

https://element-plus.gitee.io/zh-CN/

# 第三方表格插件
https://github.com/x-extends/vxe-table

https://xuliangzhan_admin.gitee.io/vxe-table/#/table/start/install

# excel插件
https://sheetjs.com/

# 社区免费版
https://github.com/sheetjs/sheetjs

# 富文本编辑器
https://github.com/vuejs/awesome-vue#rich-text-editing

https://github.com/wangeditor-team/wangEditor

https://www.wangeditor.com/

https://www.wangeditor.com/doc/

# 拖拽组件
https://github.com/vuejs/awesome-vue#drag-and-drop

https://github.com/SortableJS/Vue.Draggable

https://github.com/SortableJS/Sortable

https://sortablejs.github.io/Sortable/

# Vue.js 3 + Vite + TypeScript 实战项目开发

本模块中我们通过使用 TypeScript 编程语言，基于 Vue.js 3 全家桶（Vue.js、Vue Router、Vuex、Vite、Element Plus 等）开发 B 端管理系统项目（dashboard)。通过实战深入掌握 Vue.js 3 及其相关技术栈的使用。


## 笔记

https://www.yuque.com/books/share/84a225ba-970e-46ee-9e72-b09a297d75fe?#（密码：slzd） 《【Vue 3 + TS 项目实战】 — 【拉勾心选电商管理系统】》

## 代码

https://gitee.com/lipengzhou/shop-admin



# Vue 3 + Typescript + Vite

This template should help get you started developing with Vue 3 and Typescript in Vite. The template uses Vue 3 `<script setup>` SFCs, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

## Recommended IDE Setup

- [VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=johnsoncodehk.volar)

## Type Support For `.vue` Imports in TS

Since TypeScript cannot handle type information for `.vue` imports, they are shimmed to be a generic Vue component type by default. In most cases this is fine if you don't really care about component prop types outside of templates. However, if you wish to get actual prop types in `.vue` imports (for example to get props validation when using manual `h(...)` calls), you can enable Volar's `.vue` type support plugin by running `Volar: Switch TS Plugin on/off` from VSCode command palette.
